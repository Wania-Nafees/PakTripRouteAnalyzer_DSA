import tkinter as tk
from tkinter import ttk, messagebox
import csv
import os
from datetime import datetime
import heapq
import math

#1. COORDINATE AND SCALE SETUP 


cities_original = {
    "Karachi": (150, 400),
    "Hyderabad": (200, 430),
    "Quetta": (250, 330),
    "Multan": (550, 300),
    "Faisalabad": (600, 250),
    "Lahore": (700, 220),
    "Sialkot": (750, 180),
    "Islamabad": (650, 160),
    "Peshawar": (600, 100),
    "Chitral": (500, 50),
    "Gilgit": (700, 50),
    "Skardu": (780, 20)
}

# Dictionary 
cities_coords = {city: (x, y) for city, (x, y) in cities_original.items()}

# Derived constant for converting straight-line pixel distance to a kilometer estimate.
PIXEL_TO_KM_RATIO = 2.83 
# NEW: Estimated cost per kilometer (e.g., fuel + wear, in PKR)
COST_PER_KM = 35.0 

# Map scaling constants
canvas_width = 550
canvas_height = 320

x_coords = [x for x, y in cities_original.values()]
y_coords = [y for x, y in cities_original.values()]

map_width = max(x_coords) - min(x_coords)
map_height = max(y_coords) - min(y_coords)

scale_x = (canvas_width - 40) / map_width
scale_y = (canvas_height - 40) / map_height
SCALE_FACTOR = min(scale_x, scale_y)

X_OFFSET = int((canvas_width - (map_width * SCALE_FACTOR)) / 2) - int(min(x_coords) * SCALE_FACTOR)
Y_OFFSET = int((canvas_height - (map_height * SCALE_FACTOR)) / 2) - int(min(y_coords) * SCALE_FACTOR)

def scale_and_offset(x, y):
    new_x = int(x * SCALE_FACTOR) + X_OFFSET
    new_y = int(y * SCALE_FACTOR) + Y_OFFSET
    return (new_x, new_y)

# Scaled coordinates 
cities = {city: scale_and_offset(x, y) for city, (x, y) in cities_original.items()}

#2. GRAPH DATA 

graph = {
    "Karachi": {"Hyderabad": 165, "Quetta": 690, "Multan": 890},
    "Hyderabad": {"Karachi": 165, "Multan": 680},
    "Quetta": {"Karachi": 690, "Multan": 830, "Peshawar": 970},
    "Multan": {"Karachi": 890, "Quetta": 830, "Faisalabad": 210, "Lahore": 350, "Islamabad": 420, "Hyderabad": 680},
    "Faisalabad": {"Multan": 210, "Lahore": 130, "Islamabad": 380},
    "Lahore": {"Multan": 350, "Faisalabad": 130, "Islamabad": 290, "Sialkot": 140, "Peshawar": 520},
    "Sialkot": {"Lahore": 140, "Islamabad": 250},
    "Islamabad": {"Multan": 420, "Faisalabad": 380, "Lahore": 290, "Sialkot": 250, "Peshawar": 180, "Gilgit": 580, "Skardu": 630},
    "Peshawar": {"Islamabad": 180, "Lahore": 520, "Quetta": 970, "Chitral": 370},
    "Chitral": {"Peshawar": 370, "Gilgit": 340},
    "Gilgit": {"Islamabad": 580, "Chitral": 340, "Skardu": 230},
    "Skardu": {"Islamabad": 630, "Gilgit": 230}
}

# Ensure graph is undirected
for u, nbrs in list(graph.items()):
    for v, d in list(nbrs.items()):
        if v not in graph:
            graph[v] = {}
        if u not in graph[v]:
            graph[v][u] = d

#  ALGORITHMS 

def true_euclidean_distance(city1, city2):
    """Calculates the straight-line distance ."""
    x1, y1 = cities_coords[city1]
    x2, y2 = cities_coords[city2]
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def a_star(start, end):
    """Implements the A* search algorithm."""
    pq = [(0, 0, start, [])]  # (f_score, g_score, node, path_so_far)
    g_scores = {city: float('inf') for city in cities}
    g_scores[start] = 0
    nodes_visited = 0

    while pq:
        f_score, g_score, node, path = heapq.heappop(pq)
        
        if g_score > g_scores.get(node, float('inf')):
            continue
            
        nodes_visited += 1
        path = path + [node]

        if node == end:
            return g_score, path, nodes_visited

        for nbr, w in graph.get(node, {}).items():
            new_g_score = g_score + w 
            
            if new_g_score < g_scores[nbr]:
                g_scores[nbr] = new_g_score
                
                pixel_dist = true_euclidean_distance(nbr, end)
                h_score = pixel_dist * PIXEL_TO_KM_RATIO
                
                f_score = new_g_score + h_score
                
                heapq.heappush(pq, (f_score, new_g_score, nbr, path))
                
    return float("inf"), [], nodes_visited

#TKINTER UI SETUP

NODE_COLOR_DEFAULT = "#004d40"  # Dark Teal
NODE_COLOR_START = "#388E3C"    # Vibrant Green
NODE_COLOR_END = "#D32F2F"      # Deep Red
NODE_COLOR_INTERMEDIATE = "#FFEB3B" # Yellow for visited
LINE_COLOR_CONNECTED = "#1E88E5" # Blue for hover
PATH_COLOR = "#FF0000"           # Red for result path
MAP_LINE_COLOR = "#A9A9A9"       # Dark Grey for base map

tooltip_label = None
saved_routes_win = None
current_highlighted_connections = []

click_selection_state = 0 

root = tk.Tk()
root.title("PK Pakistan Travel Journey PLANNER")
root.geometry("950x750") 
root.configure(bg="#f0fff5") 

header = tk.Label(
    root, text="PakTrip Route Analyzer",
    font=("Verdana", 24, "bold"),
    bg="#1E8449", fg="white", pady=10 
)
header.pack(fill=tk.X)

canvas = tk.Canvas(root, width=550, height=320, bg="#f7f7f7", highlightthickness=2, relief="sunken") # Pale map background
canvas.pack(pady=20)

def show_tooltip(event, city1, city2, distance):
    global tooltip_label
    if tooltip_label:
        tooltip_label.destroy()
    tooltip_label = tk.Label(
        root, text=f"{city1} ↔ {city2}: {distance} km",
        bg="#ffffe0", fg="black", relief='solid', borderwidth=1, font=("Arial", 9)
    )
    x = root.winfo_pointerx() + 10
    y = root.winfo_pointery() + 10
    tooltip_label.wm_geometry(f"+{x}+{y}")
    tooltip_label.lift()

def hide_tooltip():
    global tooltip_label
    if tooltip_label:
        tooltip_label.destroy()
        tooltip_label = None

def set_city_from_click(city_name):
    """Sets the clicked city into the From or To combobox based on the current state."""
    global click_selection_state
    
    if click_selection_state == 0:
        from_cb.set(city_name)
        status_label.config(text=f"**Start City** set to **{city_name}**. Click again for Destination.")
        click_selection_state = 1
    else:
        to_cb.set(city_name)
        status_label.config(text=f"**Destination** set to **{city_name}**. Click 'Find Path' to search.")
        click_selection_state = 0
        
    # Highlight connections of the last set city
    highlight_connections(city_name=city_name)

# Draw base map lines
base_lines = []
for city1, connections in graph.items():
    for city2, dist in connections.items():
        if city1 < city2:
            x1, y1 = cities[city1]
            x2, y2 = cities[city2]
            line_tag = f"line_{city1}_{city2}"
            line_id = canvas.create_line(x1, y1, x2, y2, fill=MAP_LINE_COLOR, width=2, tags=(line_tag,))
            base_lines.append(line_id)
            canvas.tag_bind(line_tag, '<Enter>', lambda event, d=dist, c1=city1, c2=city2: show_tooltip(event, c1, c2, d))
            canvas.tag_bind(line_tag, '<Leave>', lambda event: hide_tooltip())

# Draw city nodes and labels
city_oval_ids = {}
for city, (x, y) in cities.items():
    oval_id = canvas.create_oval(x-7, y-7, x+7, y+7, fill=NODE_COLOR_DEFAULT, outline="white", width=2, tags=(f"node_{city}",))
    city_oval_ids[city] = oval_id
    canvas.create_text(x, y-17, text=city, font=("Arial", 10, "bold"), fill="#001f33")
    
    # Bind click event for city selection
    canvas.tag_bind(f"node_{city}", '<Button-1>', lambda event, c=city: set_city_from_click(c))

# Input Frame
frame = tk.Frame(root, bg="#ffffff", pady=10, relief="ridge", bd=2)
frame.pack(fill=tk.X, padx=20)

tk.Label(frame, text="From:", bg="#ffffff", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=(10, 5))
from_cb = ttk.Combobox(frame, values=list(cities.keys()), width=15, state='readonly')
from_cb.grid(row=0, column=1, padx=5, ipady=3)
from_cb.set("Lahore")

tk.Label(frame, text="To:", bg="#ffffff", font=("Arial", 11, "bold")).grid(row=0, column=2, padx=(10, 5))
to_cb = ttk.Combobox(frame, values=list(cities.keys()), width=15, state='readonly')
to_cb.grid(row=0, column=3, padx=5, ipady=3)
to_cb.set("Gilgit")

# Route Details Output Box
info_box = tk.LabelFrame(root, text="Route Details", bg="#f0f5ff", font=("Arial", 11, "bold"), fg="#004080", padx=10, pady=10)
info_box.pack(pady=10, fill="x", padx=20)

route_label = tk.Label(info_box, text="Shortest Route: -", bg="#f0f5ff", font=("Arial", 11, "bold"), anchor="w")
route_label.grid(row=0, column=0, columnspan=2, sticky="ew", pady=3)

distance_label = tk.Label(info_box, text="Distance: Total Distance - km", bg="#f0f5ff", font=("Arial", 11), anchor="w")
distance_label.grid(row=1, column=0, sticky="ew", padx=(0, 10))

time_label = tk.Label(info_box, text="Time: Estimated Travel Time: -", bg="#f0f5ff", font=("Arial", 11), anchor="w")
time_label.grid(row=1, column=1, sticky="ew", padx=(10, 0))

# NEW: Estimated Cost Label
cost_label = tk.Label(info_box, text="Cost: Estimated Cost - PKR", bg="#f0f5ff", font=("Arial", 11, "bold"), fg="#004080", anchor="w")
cost_label.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(5, 0))

# Configure columns to expand
info_box.grid_columnconfigure(0, weight=1)
info_box.grid_columnconfigure(1, weight=1)

status_label = tk.Label(root, text="Click a city on the map or select from the menus above.", bg="#f0fff5", font=("Arial", 10))
status_label.pack(pady=5)

city_map = {k.lower().strip(): k for k in cities.keys()}
def normalize_city(name):
    if not name: return ""
    key = name.lower().strip()
    return city_map.get(key, "")

highlight_ids = []

def clear_highlight():
    """Clears all map highlights and resets all labels."""
    global highlight_ids, current_highlighted_connections, click_selection_state
    hide_tooltip()
    click_selection_state = 0 # Reset click state
    for oval_id in city_oval_ids.values():
        canvas.itemconfig(oval_id, fill=NODE_COLOR_DEFAULT, outline="white", width=2)
    for hid in highlight_ids:
        try: canvas.delete(hid)
        except: pass
    highlight_ids = []
    for conn_id in current_highlighted_connections:
        try: canvas.delete(conn_id)
        except: pass
    current_highlighted_connections = []
    # Reset label text to placeholder state
    route_label.config(text="Shortest Route: -")
    distance_label.config(text="Distance: Total Distance - km")
    time_label.config(text="Time: Estimated Travel Time: -")
    cost_label.config(text="Cost: Estimated Cost - PKR")
    status_label.config(text="Map cleared. Ready to plan your next journey!")

def highlight_connections(event=None, city_name=None):
    global current_highlighted_connections
    selected_city = city_name or (from_cb.get() if event and event.widget == from_cb else to_cb.get())
    
    if not selected_city or selected_city not in cities:
        return
        
    # Only clear connections/highlights, not the result labels
    for conn_id in current_highlighted_connections:
        try: canvas.delete(conn_id)
        except: pass
    current_highlighted_connections = []
    for oval_id in city_oval_ids.values():
        canvas.itemconfig(oval_id, fill=NODE_COLOR_DEFAULT, outline="white", width=2)
    
    canvas.itemconfig(city_oval_ids[selected_city], fill=NODE_COLOR_START, outline="cyan", width=3)
    x1, y1 = cities[selected_city]
    
    for neighbor, dist in graph.get(selected_city, {}).items():
        x2, y2 = cities[neighbor]
        line_id = canvas.create_line(x1, y1, x2, y2, fill=LINE_COLOR_CONNECTED, width=3, dash=(5, 2))
        current_highlighted_connections.append(line_id)
        canvas.itemconfig(city_oval_ids[neighbor], fill=NODE_COLOR_INTERMEDIATE, outline="cyan", width=2)
        
    status_label.config(text=f"Showing direct connections from **{selected_city}**.")
    root.update_idletasks()

# --- 5. CSV LOGGING FUNCTIONS ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_FILE = os.path.join(BASE_DIR, "routes.csv")
CSV_FIELDS = ["timestamp", "raw_from", "raw_to", "from_normalized", "to_normalized", "distance_km", "hours", "minutes", "path", "cost_pkr"]

def save_route_to_csv(raw_from, raw_to, from_norm, to_norm, dist, hours, minutes, path_list, cost):
    need_header = not os.path.exists(CSV_FILE)
    with open(CSV_FILE, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if need_header:
            writer.writeheader()
        writer.writerow({
            "timestamp": datetime.now().isoformat(sep=" ", timespec="seconds"),
            "raw_from": raw_from,
            "raw_to": raw_to,
            "from_normalized": from_norm,
            "to_normalized": to_norm,
            "distance_km": dist,
            "hours": hours,
            "minutes": minutes,
            "path": "→".join(path_list),
            "cost_pkr": cost
        })

def read_saved_routes():
    if not os.path.exists(CSV_FILE):
        return []
    rows = []
    with open(CSV_FILE, mode="r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return rows

def show_saved_routes_window():
    global saved_routes_win
    if saved_routes_win is not None and tk.Toplevel.winfo_exists(saved_routes_win):
        saved_routes_win.lift()
        saved_routes_win.focus_force()
        return
    rows = read_saved_routes()
    saved_routes_win = tk.Toplevel(root)
    saved_routes_win.title("Saved Routes")
    saved_routes_win.geometry("900x400")
    txt = tk.Text(saved_routes_win, wrap="none", font=("Consolas", 9))
    vsb = tk.Scrollbar(saved_routes_win, orient="vertical", command=txt.yview)
    hsb = tk.Scrollbar(saved_routes_win, orient="horizontal", command=txt.xview)
    txt.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    vsb.pack(side="right", fill="y")
    hsb.pack(side="bottom", fill="x")
    txt.pack(fill=tk.BOTH, expand=True)
    txt.configure(state=tk.NORMAL)
    if not rows:
        txt.insert(tk.END, "No saved routes found.\n")
    else:
        header_line = "{:<20} | {:<10} -> {:<10} | {:<10} | {:<8} | {:<10} | {}\n".format(
            "TIMESTAMP", "FROM", "TO", "DISTANCE (km)", "TIME", "COST (PKR)", "ROUTE"
        )
        txt.insert(tk.END, header_line, 'header')
        txt.tag_configure('header', background='#ccc', foreground='#000', font=('Consolas', 9, 'bold'))
        txt.insert(tk.END, "-" * 120 + "\n")
        for r in reversed(rows):
            time_str = f"{r['hours']}h {r['minutes']}m"
            line = "{:<20} | {:<10} -> {:<10} | {:<10} | {:<8} | {:<10} | {}\n".format(
                r['timestamp'], r['from_normalized'], r['to_normalized'], r['distance_km'], time_str, r.get('cost_pkr', 'N/A'), r['path']
            )
            txt.insert(tk.END, line)
    txt.config(state=tk.DISABLED)

# --- 6. MAIN ROUTE FUNCTION ---

def show_and_animate_route():
    raw_start = from_cb.get()
    raw_end = to_cb.get()
    start = normalize_city(raw_start)
    end = normalize_city(raw_end)
    
    if not start or not end:
        messagebox.showwarning("Missing Selection", "Please select valid 'From' and 'To' cities.")
        return
    if start == end:
        messagebox.showinfo("Same City", "You selected the same city.")
        return
    
    # 1. Run A* search
    dist, path, nodes_visited = a_star(start, end)
    
    if dist == float("inf") or not path:
        messagebox.showerror("No Route", "No route found between the selected cities.")
        return
        
    # 2. Calculate time and cost
    avg_speed = 80.0
    time_hours = dist / avg_speed
    hours = int(time_hours)
    minutes = int(round((time_hours - hours) * 60))
    total_cost = dist * COST_PER_KM
    
    # 3. Update UI text (showing results)
    route_label.config(text=f"Shortest Route: {' → '.join(path)}")
    distance_label.config(text=f"Distance: Total Distance {dist:.0f} km") 
    time_label.config(text=f"Time: Estimated Travel Time {hours}h {minutes}m")
    cost_label.config(text=f"Cost: Estimated Cost {total_cost:,.0f} PKR")
    status_label.config(text=f"A* Search completed! Nodes visited: {nodes_visited}")
    root.update_idletasks() 

    # 4. Save route
    try:
        save_route_to_csv(raw_start, raw_end, start, end, f"{dist:.0f}", hours, minutes, path, f"{total_cost:,.0f}")
    except Exception as e:
        messagebox.showwarning("Save Failed", f"Error saving route: {e}")
        
    # 5. Clear old map highlights
    global highlight_ids, current_highlighted_connections
    for hid in highlight_ids:
        try: canvas.delete(hid)
        except: pass
    highlight_ids = []
    for conn_id in current_highlighted_connections:
        try: canvas.delete(conn_id)
        except: pass
    current_highlighted_connections = []
    
    # Reset all node colors to default before highlighting the path
    for oval_id in city_oval_ids.values():
        canvas.itemconfig(oval_id, fill=NODE_COLOR_DEFAULT, outline="white", width=2)
        
    # 6. Highlight the new path
    canvas.itemconfig(city_oval_ids[start], fill=NODE_COLOR_START, outline=PATH_COLOR, width=3)
    canvas.itemconfig(city_oval_ids[end], fill=NODE_COLOR_END, outline=PATH_COLOR, width=3)
    
    for city in path[1:-1]:
        canvas.itemconfig(city_oval_ids[city], fill=NODE_COLOR_INTERMEDIATE, outline="yellow", width=2)
    
    coords = [cities[c] for c in path]
    
    # Draw path lines
    for i in range(len(coords) - 1):
        x1, y1 = coords[i]
        x2, y2 = coords[i + 1]
        # Increased path width for visibility
        hid = canvas.create_line(x1, y1, x2, y2, fill=PATH_COLOR, width=5) 
        highlight_ids.append(hid)
        
    # 7. Start animation
    dot = canvas.create_oval(coords[0][0]-7, coords[0][1]-7, coords[0][0]+7, coords[0][1]+7, fill="yellow", outline="black", width=1)
    highlight_ids.append(dot)
    
    steps_each = 50
    delay_ms = 20
    
    def animate_segment(seg_index=0, step_index=0):
        if seg_index >= len(coords) - 1:
            status_label.config(text=f"Animation completed. **{start} → {end}** (Nodes visited: {nodes_visited})")
            return
            
        x1, y1 = coords[seg_index]
        x2, y2 = coords[seg_index + 1]
        
        if step_index <= steps_each:
            t = step_index / steps_each
            nx = x1 + (x2 - x1) * t
            ny = y1 + (y2 - y1) * t
            canvas.coords(dot, nx-7, ny-7, nx+7, ny+7)
            root.after(delay_ms, animate_segment, seg_index, step_index + 1)
        else:
            root.after(delay_ms, animate_segment, seg_index + 1, 0)
            
    animate_segment(0, 0)

# --- 7. BUTTONS AND BINDINGS ---

btn = tk.Button(frame, text="Find Shortest Path", command=show_and_animate_route, bg="#1E8449", fg="white", font=("Arial", 10, "bold"), width=18)
btn.grid(row=0, column=4, padx=15)

show_btn = tk.Button(frame, text="Show Saved Routes", command=show_saved_routes_window, bg="#004d40", fg="white", font=("Arial", 10), width=18)
show_btn.grid(row=0, column=5, padx=5)

clear_btn = tk.Button(frame, text="Clear Map", command=clear_highlight, bg="#808080", fg="white", font=("Arial", 10), width=15)
clear_btn.grid(row=0, column=6, padx=5)

from_cb.bind("<<ComboboxSelected>>", highlight_connections)
to_cb.bind("<<ComboboxSelected>>", highlight_connections)

root.mainloop()